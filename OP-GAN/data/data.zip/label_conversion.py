import numpy as np


with open(r"labels.npy", "rb") as f:
    labels = np.load(f)


print(labels)
a = set(labels.flatten().tolist())
missings = [12, 26, 29, 30, 45, 66, 68, 69, 71, 83, 91]

for i in range(labels.shape[0]):
    for j in range(labels.shape[1]):
        assert(labels[i][j] not in missings)
        labels[i][j] -= np.searchsorted(missings,labels[i][j])
        #For indexing
        labels[i][j] -= 1


assert(np.max(labels) == 79)


with open(r"labels_transformed.npy", "wb") as f:
    np.save(f, labels)